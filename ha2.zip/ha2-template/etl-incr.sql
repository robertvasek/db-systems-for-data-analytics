-- This script must be able to run as is, i.e., psql <etl-incr.sql
-- This script may not be "idempotent", so you may not include commands for "new data cleanup"

-- This SQL script that will:
-- 1/ update the necessary dimension tables



-- 2/ inserts new facts into tracking




